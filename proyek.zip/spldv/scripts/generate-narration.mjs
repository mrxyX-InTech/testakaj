// Membuat file narasi (mp3) per segmen dari src/narration.json memakai ElevenLabs.
// Pemakaian:
//   ELEVENLABS_API_KEY=xxx ELEVENLABS_VOICE_ID=yyy npm run narasi
// Hasil: public/narasi/<id>.mp3. Lalu set HAS_NARRATION = true di src/config.ts.
// Pilih suara yang mendukung Bahasa Indonesia (model eleven_multilingual_v2).
import {readFileSync, writeFileSync, mkdirSync, existsSync} from 'node:fs';

const key = process.env.ELEVENLABS_API_KEY;
const voice = process.env.ELEVENLABS_VOICE_ID;
if (!key || !voice) {
  console.error('Set ELEVENLABS_API_KEY dan ELEVENLABS_VOICE_ID dulu.');
  process.exit(1);
}

const data = JSON.parse(readFileSync(new URL('../src/narration.json', import.meta.url), 'utf8'));
const outDir = new URL('../public/narasi/', import.meta.url);
mkdirSync(outDir, {recursive: true});

for (const [scene, segs] of Object.entries(data)) {
  for (const seg of segs) {
    const file = new URL(`${seg.id}.mp3`, outDir);
    if (existsSync(file) && !process.argv.includes('--force')) {
      console.log('lewati (sudah ada):', seg.id);
      continue;
    }
    const res = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${voice}?output_format=mp3_44100_128`,
      {
        method: 'POST',
        headers: {'xi-api-key': key, 'Content-Type': 'application/json'},
        body: JSON.stringify({
          text: seg.text,
          model_id: 'eleven_multilingual_v2',
          language_code: 'id',
          voice_settings: {stability: 0.5, similarity_boost: 0.75, style: 0.2},
        }),
      },
    );
    if (!res.ok) {
      console.error('Gagal:', scene, seg.id, res.status, await res.text());
      process.exit(1);
    }
    writeFileSync(file, Buffer.from(await res.arrayBuffer()));
    console.log('ok:', seg.id);
  }
}
console.log('Selesai. Jalankan: node scripts/check-narration.mjs');
