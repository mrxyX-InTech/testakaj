// Memeriksa apakah tiap file narasi muat di jeda sebelum segmen berikutnya
// (atau sebelum scene berakhir). Butuh ffprobe (bagian dari ffmpeg).
import {readFileSync, existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';

const data = JSON.parse(readFileSync(new URL('../src/narration.json', import.meta.url), 'utf8'));
const sceneSeconds = {intro: 16, define: 57, eliminate: 70, substitute: 66, graph: 70, mixed: 72, summary: 36};
let problems = 0;
for (const [scene, segs] of Object.entries(data)) {
  segs.forEach((seg, i) => {
    const file = new URL(`../public/narasi/${seg.id}.mp3`, import.meta.url);
    if (!existsSync(file)) {
      console.log('BELUM ADA  ', seg.id);
      problems++;
      return;
    }
    const dur = parseFloat(
      execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file.pathname]).toString(),
    );
    const limit = (i + 1 < segs.length ? segs[i + 1].at : sceneSeconds[scene] - 0.5) - seg.at;
    const ok = dur <= limit - 0.3;
    if (!ok) problems++;
    console.log(ok ? 'ok         ' : 'TERLALU PANJANG', seg.id, `durasi ${dur.toFixed(1)}s / jatah ${limit.toFixed(1)}s`);
  });
}
console.log(problems ? `${problems} masalah` : 'Semua narasi muat.');
