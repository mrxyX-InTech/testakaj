# Naskah Narasi - SPLDV (MrXyStudy)

Setiap segmen dimulai tepat pada detik yang tertera (relatif terhadap awal scene) dan sudah disinkronkan dengan animasinya. Rekam/hasilkan satu file per segmen, beri nama `<id>.mp3`, simpan di `public/narasi/`.


## Pembuka

- **intro-1** (detik 1.5): Halo, teman-teman! Selamat datang di MrXyStudy. Hari ini kita belajar SPLDV, yaitu Sistem Persamaan Linear Dua Variabel. Ada empat cara menyelesaikannya, dan kita bahas satu per satu.

## 1. Pengertian SPLDV

- **define-1** (detik 1.5): SPLDV adalah singkatan dari Sistem Persamaan Linear Dua Variabel. Artinya, ada dua persamaan linear, dan keduanya memuat dua variabel yang sama, yaitu x dan y.
- **define-2** (detik 15): Perhatikan contoh ini. Persamaan pertama: dua x ditambah y sama dengan tujuh. Persamaan kedua: x ditambah y sama dengan lima.
- **define-3** (detik 26): Menyelesaikan SPLDV berarti mencari nilai x dan y yang memenuhi kedua persamaan sekaligus.
- **define-4** (detik 33): Coba x sama dengan dua dan y sama dengan tiga. Persamaan pertama: dua kali dua ditambah tiga sama dengan tujuh. Benar.
- **define-5** (detik 44): Persamaan kedua: dua ditambah tiga sama dengan lima. Juga benar. Jadi, penyelesaiannya adalah x sama dengan dua dan y sama dengan tiga.

## 2. Metode Eliminasi

- **eliminate-1** (detik 1.5): Eliminasi artinya menghilangkan. Kita hilangkan salah satu variabel, supaya tinggal satu variabel saja.
- **eliminate-2** (detik 8.5): Perhatikan, koefisien y di kedua persamaan sudah sama, yaitu satu. Jadi kita tidak perlu menyamakan koefisien lagi.
- **eliminate-3** (detik 17.5): Karena koefisien y sama dan bertanda sama, kita kurangkan persamaan pertama dengan persamaan kedua.
- **eliminate-4** (detik 25): y dikurangi y sama dengan nol, jadi variabel y hilang, atau tereliminasi.
- **eliminate-5** (detik 31): Sekarang hitung sisanya. Dua x dikurangi x sama dengan x, dan tujuh dikurangi lima sama dengan dua. Jadi, x sama dengan dua.
- **eliminate-6** (detik 42): Langkah terakhir, substitusikan x sama dengan dua ke persamaan kedua. Dua ditambah y sama dengan lima, maka y sama dengan lima dikurangi dua, yaitu tiga.
- **eliminate-7** (detik 54.5): Hasilnya, x sama dengan dua dan y sama dengan tiga.
- **eliminate-8** (detik 60): Kalau koefisiennya belum sama, kita kalikan dulu persamaannya. Contohnya nanti ada di metode campuran.

## 3. Metode Substitusi

- **substitute-1** (detik 1.5): Pada substitusi, kita mengganti satu variabel dengan bentuk yang setara. Kita pakai contoh yang sama.
- **substitute-2** (detik 9): Pertama, ubah persamaan kedua menjadi y sama dengan sesuatu. Dari x ditambah y sama dengan lima, pindahkan x ke ruas kanan. Maka y sama dengan lima dikurangi x.
- **substitute-3** (detik 22.5): Kedua, masukkan bentuk ini ke persamaan pertama, menggantikan y. Jadi dua x ditambah lima dikurangi x, sama dengan tujuh.
- **substitute-4** (detik 32): Ketiga, selesaikan persamaannya. Dua x dikurangi x menjadi x, sehingga x ditambah lima sama dengan tujuh. Kurangi kedua ruas dengan lima, maka x sama dengan dua.
- **substitute-5** (detik 45): Keempat, cari y. Masukkan x sama dengan dua ke y sama dengan lima dikurangi x. Maka y sama dengan lima dikurangi dua, yaitu tiga.
- **substitute-6** (detik 57): Hasilnya sama dengan metode eliminasi: x sama dengan dua dan y sama dengan tiga.

## 4. Metode Grafik

- **graph-1** (detik 1.5): Metode grafik menyelesaikan SPLDV dengan menggambar kedua persamaan sebagai garis lurus.
- **graph-2** (detik 8): Langkah pertama, ubah setiap persamaan menjadi y sama dengan sesuatu. Dua x ditambah y sama dengan tujuh menjadi y sama dengan tujuh dikurangi dua x. Dan x ditambah y sama dengan lima menjadi y sama dengan lima dikurangi x.
- **graph-3** (detik 27): Langkah kedua, pilih beberapa nilai x lalu hitung y. Garis pertama melewati titik nol tujuh, satu lima, dua tiga, dan tiga satu. Garis kedua melewati nol lima, satu empat, dua tiga, dan tiga dua.
- **graph-4** (detik 48): Langkah ketiga, hubungkan titik-titik tadi menjadi garis lurus. Garis pertama berwarna biru, garis kedua berwarna putih.
- **graph-5** (detik 57): Langkah keempat: kedua garis berpotongan di satu titik, yaitu dua koma tiga. Jadi x sama dengan dua dan y sama dengan tiga.

## 5. Metode Campuran

- **mixed-1** (detik 1.5): Metode campuran menggabungkan eliminasi dan substitusi. Kita pakai contoh baru: tiga x ditambah dua y sama dengan dua belas, dan x ditambah y sama dengan lima.
- **mixed-2** (detik 13): Pertama, eliminasi. Koefisien y belum sama, yaitu dua dan satu. Kalikan persamaan kedua dengan dua, sehingga menjadi dua x ditambah dua y sama dengan sepuluh.
- **mixed-3** (detik 25): Sekarang koefisien y sama-sama dua, jadi kita kurangkan. Dua y dikurangi dua y habis. Tiga x dikurangi dua x sama dengan x, dan dua belas dikurangi sepuluh sama dengan dua. Maka x sama dengan dua.
- **mixed-4** (detik 42): Kedua, substitusi. Masukkan x sama dengan dua ke persamaan kedua. Dua ditambah y sama dengan lima, jadi y sama dengan tiga.
- **mixed-5** (detik 52): Ketiga, verifikasi. Masukkan x dua dan y tiga ke kedua persamaan. Persamaan pertama: tiga kali dua ditambah dua kali tiga, enam ditambah enam, sama dengan dua belas. Benar. Persamaan kedua: dua ditambah tiga sama dengan lima. Benar juga.

## 6. Kesimpulan

- **summary-1** (detik 1.5): Mari kita rangkum. Ada empat metode untuk menyelesaikan SPLDV.
- **summary-2** (detik 6.5): Eliminasi, yaitu menghilangkan salah satu variabel.
- **summary-3** (detik 10.5): Substitusi, yaitu memasukkan bentuk variabel ke persamaan lainnya.
- **summary-4** (detik 15): Grafik, yaitu mencari titik potong dua garis.
- **summary-5** (detik 19): Dan campuran, yaitu menggabungkan eliminasi dan substitusi.
- **summary-6** (detik 23): Semua metode menghasilkan jawaban yang sama: x sama dengan dua dan y sama dengan tiga. Pilih cara yang paling nyaman untukmu. Sampai jumpa di video berikutnya!
