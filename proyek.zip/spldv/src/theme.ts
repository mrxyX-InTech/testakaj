export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export const C = {
  bg: '#0A0C10',
  fg: '#F4F6FA',
  muted: '#8B93A5',
  accent: '#3B82F6',
  x: '#5BA8FF', // variabel x
  y: '#FFB347', // variabel y
  strike: '#FF5D5D',
  ok: '#4ADE80',
  rule: 'rgba(255,255,255,0.14)',
  grid: 'rgba(255,255,255,0.08)',
};

export const MARGIN_X = 120;
