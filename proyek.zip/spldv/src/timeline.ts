import {FPS} from './theme';

export const SCENE_ORDER = [
  'intro',
  'define',
  'eliminate',
  'substitute',
  'graph',
  'mixed',
  'summary',
] as const;

export type SceneKey = (typeof SCENE_ORDER)[number];

// Durasi tiap scene (detik). Total 387 detik = 6 menit 27 detik.
export const SCENE_SECONDS: Record<SceneKey, number> = {
  intro: 16,
  define: 57,
  eliminate: 70,
  substitute: 66,
  graph: 70,
  mixed: 72,
  summary: 36,
};

export const sceneFrames = (k: SceneKey) => Math.round(SCENE_SECONDS[k] * FPS);

export const TOTAL_FRAMES = SCENE_ORDER.reduce((sum, k) => sum + sceneFrames(k), 0);
