import React from 'react';
import {useCurrentFrame} from 'remotion';
import {prog} from '../anim';

type Props = {
  at: number; // detik muncul (relatif terhadap awal scene)
  out?: number; // detik mulai menghilang
  dur?: number;
  dy?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
};

/** Memunculkan elemen secara halus (fade + naik sedikit). */
export const Reveal: React.FC<Props> = ({at, out, dur = 0.6, dy = 14, style, children}) => {
  const frame = useCurrentFrame();
  const pin = prog(frame, at, dur);
  const pout = out === undefined ? 0 : prog(frame, out, 0.5);
  return (
    <div
      style={{
        opacity: pin * (1 - pout),
        transform: `translateY(${(1 - pin) * dy}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};
