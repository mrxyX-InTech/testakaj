import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C, MARGIN_X} from '../theme';
import {prog} from '../anim';
import {SceneKey, sceneFrames} from '../timeline';
import {Narration} from './Narration';
import {fontFamily} from '../font';

type Props = {
  scene: SceneKey;
  tag?: string; // mis. "BAGIAN 1"
  title?: string;
  children: React.ReactNode;
};

/**
 * Kerangka tiap scene: latar, judul (komponen judul reusable),
 * fade masuk/keluar antar-scene, dan jalur narasi.
 */
export const SceneShell: React.FC<Props> = ({scene, tag, title, children}) => {
  const frame = useCurrentFrame();
  const total = sceneFrames(scene);
  const fade = interpolate(frame, [0, 12, total - 12, total], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const t = prog(frame, 0.2, 0.8);
  const bar = prog(frame, 0.5, 0.9);

  return (
    <AbsoluteFill style={{background: C.bg, color: C.fg, fontFamily: `${fontFamily}, 'Segoe UI', Helvetica, Arial, sans-serif`}}>
      <AbsoluteFill style={{opacity: fade}}>
        {title ? (
          <div
            style={{
              position: 'absolute',
              left: MARGIN_X,
              top: 84,
              opacity: t,
              transform: `translateY(${(1 - t) * 14}px)`,
            }}
          >
            <div style={{fontSize: 30, letterSpacing: 6, color: C.accent, fontWeight: 700}}>{tag}</div>
            <div style={{fontSize: 84, fontWeight: 700, lineHeight: 1.1, marginTop: 6, letterSpacing: -1}}>
              {title}
            </div>
            <div
              style={{
                marginTop: 18,
                height: 6,
                width: 180 * bar,
                borderRadius: 3,
                background: C.accent,
              }}
            />
          </div>
        ) : null}
        {children}
      </AbsoluteFill>
      <Narration scene={scene} />
    </AbsoluteFill>
  );
};
