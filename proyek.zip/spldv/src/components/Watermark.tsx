import React from 'react';
import {Img, staticFile} from 'remotion';

// Logo MrXyStudy: putih, opacity 70%, pojok kanan atas, ukuran konstan.
// Rasio asli logo dipertahankan (hanya width yang diatur, height otomatis).
export const Watermark: React.FC = () => (
  <Img
    src={staticFile('logo-white.png')}
    style={{
      position: 'absolute',
      top: 52,
      right: 76,
      width: 150,
      height: 'auto',
      opacity: 0.7,
    }}
  />
);
