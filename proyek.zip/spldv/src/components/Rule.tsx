import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {prog} from '../anim';

/** Garis yang digambar dari kiri ke kanan. */
export const Rule: React.FC<{
  at: number;
  width: number;
  dur?: number;
  color?: string;
  thickness?: number;
}> = ({at, width, dur = 0.7, color = C.fg, thickness = 5}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, at, dur);
  return (
    <div style={{height: thickness, width}}>
      <div
        style={{
          height: '100%',
          width: `${p * 100}%`,
          background: color,
          borderRadius: thickness / 2,
          opacity: 0.85,
        }}
      />
    </div>
  );
};

/** Kotak penanda yang melingkupi satu baris/elemen (posisi absolut di dalam parent relative). */
export const BoxOverlay: React.FC<{at: number; until?: number; color?: string}> = ({
  at,
  until,
  color = C.accent,
}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, at, 0.6);
  const keep = until === undefined ? 1 : 1 - prog(frame, until, 0.4);
  return (
    <div
      style={{
        position: 'absolute',
        inset: '-4px -24px',
        border: `4px solid ${color}`,
        borderRadius: 18,
        opacity: p * keep,
        transform: `scale(${1.04 - 0.04 * p})`,
      }}
    />
  );
};
