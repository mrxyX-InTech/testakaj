import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {prog} from '../anim';

export type Mark = {
  kind: 'strike' | 'box' | 'hl';
  at: number;
  dur?: number;
  color?: string;
  /** true: tandai seluruh teks. false/kosong: hanya bagian di dalam [ ... ] */
  all?: boolean;
  /** detik tanda mulai menghilang (khusus kotak/sorot) */
  until?: number;
};

const Marked: React.FC<{mark: Mark; children: React.ReactNode}> = ({mark, children}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, mark.at, mark.dur ?? 0.7);
  const color = mark.color ?? (mark.kind === 'strike' ? C.strike : C.accent);
  const keep = mark.until === undefined ? 1 : 1 - prog(frame, mark.until, 0.4);
  return (
    <span style={{position: 'relative', display: 'inline-block'}}>
      {mark.kind === 'hl' ? (
        <span
          style={{
            position: 'absolute',
            inset: '-4px -10px',
            borderRadius: 12,
            background: color,
            opacity: 0.28 * p * keep,
          }}
        />
      ) : null}
      {children}
      {mark.kind === 'box' ? (
        <span
          style={{
            position: 'absolute',
            inset: '-6px -14px',
            border: `4px solid ${color}`,
            borderRadius: 16,
            opacity: p * keep,
            transform: `scale(${1.12 - 0.12 * p})`,
          }}
        />
      ) : null}
      {mark.kind === 'strike' ? (
        <span
          style={{
            position: 'absolute',
            left: -10,
            top: '54%',
            height: 7,
            borderRadius: 4,
            background: color,
            width: `calc((100% + 20px) * ${p})`,
            transform: 'rotate(-5deg)',
            transformOrigin: 'left center',
          }}
        />
      ) : null}
    </span>
  );
};

const plain = (str: string, key: string) =>
  str.split('').map((ch, i) => {
    const shown = ch === '-' ? '\u2212' : ch === '*' ? '\u00d7' : ch;
    const col = ch === 'x' ? C.x : ch === 'y' ? C.y : undefined;
    return (
      <span key={`${key}${i}`} style={col ? {color: col} : undefined}>
        {shown}
      </span>
    );
  });

type Props = {
  s: string;
  size?: number;
  weight?: number;
  color?: string;
  mark?: Mark | Mark[];
  style?: React.CSSProperties;
};

/**
 * Teks matematika. Huruf x otomatis biru, y otomatis oranye.
 * "-" ditampilkan sebagai tanda minus, "*" sebagai tanda kali.
 * Bagian dalam [ ] dapat diberi tanda (coret / kotak / sorot) lewat prop `mark`.
 */
export const M: React.FC<Props> = ({s, size, weight = 600, color, mark, style}) => {
  const marks = mark ? (Array.isArray(mark) ? mark : [mark]) : [];
  const partial = marks.filter((m) => !m.all);
  const whole = marks.filter((m) => m.all);
  const parts = s.split(/(\[[^\]]*\])/g);

  const content = parts.map((p, i) => {
    if (p.startsWith('[') && p.endsWith(']')) {
      let inner: React.ReactNode = <>{plain(p.slice(1, -1), `m${i}-`)}</>;
      partial.forEach((m) => {
        inner = <Marked mark={m}>{inner}</Marked>;
      });
      return <React.Fragment key={i}>{inner}</React.Fragment>;
    }
    return <React.Fragment key={i}>{plain(p, `p${i}-`)}</React.Fragment>;
  });

  let node: React.ReactNode = <>{content}</>;
  whole.forEach((m) => {
    node = <Marked mark={m}>{node}</Marked>;
  });

  return (
    <span
      style={{
        fontSize: size,
        fontWeight: weight,
        color: color ?? C.fg,
        whiteSpace: 'pre',
        fontVariantNumeric: 'tabular-nums',
        ...style,
      }}
    >
      {node}
    </span>
  );
};
