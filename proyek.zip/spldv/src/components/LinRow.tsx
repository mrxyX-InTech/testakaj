import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {prog} from '../anim';
import {M, Mark} from './M';

type MarkProp = Mark | Mark[];

type Props = {
  lead?: string; // tanda operasi di kiri, mis. "-"
  leadAt?: number;
  a?: string; // suku x
  sign?: string;
  b?: string; // suku y
  eq?: string;
  c?: string; // ruas kanan
  size?: number;
  aMark?: MarkProp;
  bMark?: MarkProp;
  cMark?: MarkProp;
};

/**
 * Satu baris persamaan dalam kolom tetap, sehingga suku x, suku y, dan
 * ruas kanan antar-baris selalu sejajar (penting untuk eliminasi).
 */
export const LinRow: React.FC<Props> = ({
  lead = '',
  leadAt = 0,
  a = '',
  sign = '',
  b = '',
  eq = '=',
  c = '',
  size = 88,
  aMark,
  bMark,
  cMark,
}) => {
  const frame = useCurrentFrame();
  const leadO = lead ? prog(frame, leadAt, 0.4) : 0;
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '0.8em 1.7em 0.9em 1.7em 0.9em 1.3em',
        alignItems: 'center',
        fontSize: size,
        lineHeight: 1.25,
        height: '1.25em',
      }}
    >
      <div style={{textAlign: 'center', opacity: leadO}}>
        {lead ? <M s={lead} color={C.muted} /> : null}
      </div>
      <div style={{textAlign: 'right'}}>{a ? <M s={a} mark={aMark} /> : null}</div>
      <div style={{textAlign: 'center'}}>{sign ? <M s={sign} color={C.muted} /> : null}</div>
      <div style={{textAlign: 'right'}}>{b ? <M s={b} mark={bMark} /> : null}</div>
      <div style={{textAlign: 'center'}}>{eq ? <M s={eq} color={C.muted} /> : null}</div>
      <div style={{textAlign: 'right'}}>{c ? <M s={c} mark={cMark} /> : null}</div>
    </div>
  );
};

/** Lebar total satu LinRow (dalam em) */
export const LINROW_EM = 7.3;
