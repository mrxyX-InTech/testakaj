import React from 'react';
import {Sequence, staticFile} from 'remotion';
import {Audio} from '@remotion/media';
import narration from '../narration.json';
import {HAS_NARRATION} from '../config';
import {s} from '../anim';
import {SceneKey} from '../timeline';

type Seg = {id: string; at: number; text: string};

/**
 * Memasang file narasi (public/narasi/<id>.mp3) tepat pada detik `at`
 * di tiap scene. Aktifkan lewat HAS_NARRATION di src/config.ts.
 */
export const Narration: React.FC<{scene: SceneKey}> = ({scene}) => {
  if (!HAS_NARRATION) return null;
  const list = (narration as unknown as Record<string, Seg[]>)[scene] ?? [];
  return (
    <>
      {list.map((seg) => (
        <Sequence key={seg.id} from={s(seg.at)} layout="none">
          <Audio src={staticFile(`narasi/${seg.id}.mp3`)} />
        </Sequence>
      ))}
    </>
  );
};
