import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {prog, s} from '../anim';

// Bidang koordinat: x dari -1 sampai 7, y dari -1 sampai 8, 1 satuan = 76 px.
const U = 76;
const XMIN = -1;
const XMAX = 7;
const YMIN = -1;
const YMAX = 8;
export const GRAPH_W = (XMAX - XMIN) * U;
export const GRAPH_H = (YMAX - YMIN) * U;

/** koordinat matematika -> piksel SVG */
const px = (x: number) => (x - XMIN) * U;
const py = (y: number) => (YMAX - y) * U;

export type GPoint = {x: number; y: number; at: number; color: string};
export type GLine = {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  at: number;
  dur: number;
  color: string;
};

type Props = {
  at: number; // detik bidang koordinat muncul
  points: GPoint[];
  lines: GLine[];
  ringAt: number; // detik titik potong disorot
  label: {x: number; y: number; text: string};
};

export const Graph: React.FC<Props> = ({at, points, lines, ringAt, label}) => {
  const frame = useCurrentFrame();
  const plane = prog(frame, at, 1);
  const ox = px(0);
  const oy = py(0);

  const xs: number[] = [];
  for (let i = XMIN; i <= XMAX; i++) xs.push(i);
  const ys: number[] = [];
  for (let i = YMIN; i <= YMAX; i++) ys.push(i);

  const ringP = prog(frame, ringAt, 0.6);
  const pulse = ((frame - s(ringAt)) % 45) / 45;
  const showPulse = frame >= s(ringAt);

  return (
    <svg
      width={GRAPH_W}
      height={GRAPH_H}
      viewBox={`0 0 ${GRAPH_W} ${GRAPH_H}`}
      style={{overflow: 'visible'}}
    >
      <g opacity={plane}>
        {xs.map((i) => (
          <line key={`gx${i}`} x1={px(i)} y1={0} x2={px(i)} y2={GRAPH_H} stroke={C.grid} strokeWidth={2} />
        ))}
        {ys.map((i) => (
          <line key={`gy${i}`} x1={0} y1={py(i)} x2={GRAPH_W} y2={py(i)} stroke={C.grid} strokeWidth={2} />
        ))}
        {/* sumbu */}
        <line x1={0} y1={oy} x2={GRAPH_W} y2={oy} stroke="rgba(255,255,255,0.7)" strokeWidth={3} />
        <line x1={ox} y1={0} x2={ox} y2={GRAPH_H} stroke="rgba(255,255,255,0.7)" strokeWidth={3} />
        <polygon
          points={`${GRAPH_W + 6},${oy} ${GRAPH_W - 12},${oy - 9} ${GRAPH_W - 12},${oy + 9}`}
          fill="rgba(255,255,255,0.7)"
        />
        <polygon points={`${ox},-6 ${ox - 9},12 ${ox + 9},12`} fill="rgba(255,255,255,0.7)" />
        {/* label angka */}
        {[1, 2, 3, 4, 5, 6, 7].map((i) => (
          <text key={`tx${i}`} x={px(i)} y={oy + 32} fill={C.muted} fontSize={26} textAnchor="middle">
            {i}
          </text>
        ))}
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <text key={`ty${i}`} x={ox - 14} y={py(i) + 9} fill={C.muted} fontSize={26} textAnchor="end">
            {i}
          </text>
        ))}
        <text x={ox - 14} y={oy + 32} fill={C.muted} fontSize={26} textAnchor="end">
          0
        </text>
        <text x={GRAPH_W - 8} y={oy - 16} fill={C.x} fontSize={38} fontWeight={700} textAnchor="end">
          x
        </text>
        <text x={ox + 18} y={34} fill={C.y} fontSize={38} fontWeight={700}>
          y
        </text>
      </g>

      {lines.map((l, i) => {
        const p = prog(frame, l.at, l.dur);
        return (
          <line
            key={`l${i}`}
            x1={px(l.x1)}
            y1={py(l.y1)}
            x2={px(l.x2)}
            y2={py(l.y2)}
            stroke={l.color}
            strokeWidth={7}
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - p}
            opacity={p > 0 ? 1 : 0}
          />
        );
      })}

      {points.map((pt, i) => {
        const p = prog(frame, pt.at, 0.4);
        return (
          <circle
            key={`p${i}`}
            cx={px(pt.x)}
            cy={py(pt.y)}
            r={11 * p}
            fill={pt.color}
            stroke={C.bg}
            strokeWidth={3}
          />
        );
      })}

      {frame >= s(ringAt) ? (
        <g>
          <circle
            cx={px(label.x)}
            cy={py(label.y)}
            r={26}
            fill="none"
            stroke={C.fg}
            strokeWidth={4}
            opacity={ringP}
          />
          {showPulse ? (
            <circle
              cx={px(label.x)}
              cy={py(label.y)}
              r={26 + 34 * pulse}
              fill="none"
              stroke={C.fg}
              strokeWidth={3}
              opacity={(1 - pulse) * 0.6 * ringP}
            />
          ) : null}
          <g opacity={prog(frame, ringAt + 0.6, 0.5)}>
            <rect
              x={px(label.x) + 34}
              y={py(label.y) - 70}
              width={150}
              height={58}
              rx={14}
              fill={C.bg}
              stroke={C.accent}
              strokeWidth={3}
            />
            <text
              x={px(label.x) + 109}
              y={py(label.y) - 28}
              fill={C.fg}
              fontSize={40}
              fontWeight={700}
              textAnchor="middle"
            >
              {label.text}
            </text>
          </g>
        </g>
      ) : null}
    </svg>
  );
};
