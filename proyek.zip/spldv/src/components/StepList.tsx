import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {s} from '../anim';
import {Rich} from './Rich';

/**
 * Daftar langkah bernomor. Langkah aktif menyala, langkah lampau meredup,
 * sehingga siswa selalu tahu sedang ada di langkah ke berapa.
 */
export const StepList: React.FC<{
  steps: string[];
  starts: number[]; // detik tiap langkah menjadi aktif
  size?: number;
  width?: number;
}> = ({steps, starts, size = 42, width = 640}) => {
  const frame = useCurrentFrame();
  const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
  return (
    <div style={{display: 'flex', flexDirection: 'column', gap: 34, width}}>
      {steps.map((t, i) => {
        const st = s(starts[i]);
        const hasNext = i < steps.length - 1;
        const nx = hasNext ? s(starts[i + 1]) : 0;
        const opacity = hasNext
          ? interpolate(frame, [st, st + 12, nx, nx + 12], [0.3, 1, 1, 0.55], clamp)
          : interpolate(frame, [st, st + 12], [0.3, 1], clamp);
        const filled = frame >= st;
        return (
          <div key={i} style={{display: 'flex', gap: 24, alignItems: 'flex-start', opacity}}>
            <div
              style={{
                width: 56,
                height: 56,
                flex: 'none',
                borderRadius: 28,
                border: `3px solid ${C.accent}`,
                background: filled ? C.accent : 'transparent',
                color: filled ? '#FFFFFF' : C.accent,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 30,
                fontWeight: 700,
              }}
            >
              {i + 1}
            </div>
            <div style={{fontSize: size, lineHeight: 1.25, fontWeight: 600, paddingTop: 2}}>
              <Rich>{t}</Rich>
            </div>
          </div>
        );
      })}
    </div>
  );
};
