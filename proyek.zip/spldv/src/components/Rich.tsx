import React from 'react';
import {C} from '../theme';

/** Teks biasa; huruf x dan y yang berdiri sendiri diberi warna variabel. */
export const Rich: React.FC<{children: string}> = ({children}) => {
  const parts = children.split(/(\b[xy]\b)/g);
  return (
    <>
      {parts.map((p, i) =>
        p === 'x' || p === 'y' ? (
          <span key={i} style={{color: p === 'x' ? C.x : C.y, fontWeight: 700}}>
            {p}
          </span>
        ) : (
          <React.Fragment key={i}>{p}</React.Fragment>
        ),
      )}
    </>
  );
};
