import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {prog} from '../anim';

/** Tanda centang yang digambar (SVG, bukan emoji). */
export const Check: React.FC<{at: number; size?: number}> = ({at, size = 56}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, at, 0.5);
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{opacity: p > 0 ? 1 : 0}}>
      <path
        d="M4 12.5 L9.5 18 L20 6.5"
        stroke={C.ok}
        strokeWidth={3}
        strokeLinecap="round"
        strokeLinejoin="round"
        pathLength={1}
        strokeDasharray={1}
        strokeDashoffset={1 - p}
      />
    </svg>
  );
};

/** Panah ke bawah (SVG) */
export const ArrowDown: React.FC<{at: number; size?: number}> = ({at, size = 44}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, at, 0.5);
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{opacity: p}}>
      <path
        d="M12 3 V20 M5 13 L12 20 L19 13"
        stroke={C.accent}
        strokeWidth={2.6}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
