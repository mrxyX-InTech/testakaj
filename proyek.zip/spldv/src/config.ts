// Ubah ke true setelah file narasi (mp3) ada di public/narasi/
// Nama file = id segmen di src/narration.json, contoh: public/narasi/intro-1.mp3
export const HAS_NARRATION = false;

export const HAS_MUSIC = true;
// Musik latar dibuat sangat pelan agar tidak mengganggu suara guru.
export const MUSIC_VOLUME = 0.1;
