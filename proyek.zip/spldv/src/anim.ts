import {Easing, interpolate} from 'remotion';
import {FPS} from './theme';

/** detik -> frame */
export const s = (sec: number) => Math.round(sec * FPS);

export const ease = Easing.bezier(0.16, 1, 0.3, 1);

/** progres 0..1 mulai detik `startSec` selama `durSec` detik (halus, tanpa overshoot) */
export const prog = (frame: number, startSec: number, durSec = 0.6) =>
  interpolate(frame, [s(startSec), s(startSec + durSec)], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: ease,
  });
