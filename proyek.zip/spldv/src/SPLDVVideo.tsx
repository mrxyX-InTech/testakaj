import React from 'react';
import {AbsoluteFill, Series, interpolate, staticFile} from 'remotion';
import {Audio} from '@remotion/media';
import {C} from './theme';
import {HAS_MUSIC, MUSIC_VOLUME} from './config';
import {SCENE_ORDER, SceneKey, TOTAL_FRAMES, sceneFrames} from './timeline';
import {Watermark} from './components/Watermark';
import {IntroScene} from './scenes/IntroScene';
import {DefineScene} from './scenes/DefineScene';
import {EliminateScene} from './scenes/EliminateScene';
import {SubstituteScene} from './scenes/SubstituteScene';
import {GraphScene} from './scenes/GraphScene';
import {MixedScene} from './scenes/MixedScene';
import {SummaryScene} from './scenes/SummaryScene';

export const SCENE_COMPONENTS: Record<SceneKey, React.FC> = {
  intro: IntroScene,
  define: DefineScene,
  eliminate: EliminateScene,
  substitute: SubstituteScene,
  graph: GraphScene,
  mixed: MixedScene,
  summary: SummaryScene,
};

export const SPLDVVideo: React.FC = () => {
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Series>
        {SCENE_ORDER.map((key) => {
          const Scene = SCENE_COMPONENTS[key];
          return (
            <Series.Sequence key={key} name={key} durationInFrames={sceneFrames(key)}>
              <Scene />
            </Series.Sequence>
          );
        })}
      </Series>

      {/* Watermark tampil sepanjang video */}
      <Watermark />

      {/* Musik latar instrumental, sangat pelan */}
      {HAS_MUSIC ? (
        <Audio
          src={staticFile('music/ambient.mp3')}
          volume={(f) =>
            MUSIC_VOLUME *
            interpolate(f, [0, 90, TOTAL_FRAMES - 120, TOTAL_FRAMES], [0, 1, 1, 0], {
              extrapolateLeft: 'clamp',
              extrapolateRight: 'clamp',
            })
          }
        />
      ) : null}
    </AbsoluteFill>
  );
};
