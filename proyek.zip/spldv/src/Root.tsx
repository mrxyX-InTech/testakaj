import React from 'react';
import {Composition, Folder} from 'remotion';
import {FPS, HEIGHT, WIDTH} from './theme';
import {SCENE_ORDER, TOTAL_FRAMES, sceneFrames} from './timeline';
import {SCENE_COMPONENTS, SPLDVVideo} from './SPLDVVideo';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="SPLDV"
        component={SPLDVVideo}
        width={WIDTH}
        height={HEIGHT}
        fps={FPS}
        durationInFrames={TOTAL_FRAMES}
      />
      {/* Tiap scene juga bisa dipratinjau sendiri di Studio */}
      <Folder name="Scenes">
        {SCENE_ORDER.map((key) => (
          <Composition
            key={key}
            id={`Scene-${key}`}
            component={SCENE_COMPONENTS[key]}
            width={WIDTH}
            height={HEIGHT}
            fps={FPS}
            durationInFrames={sceneFrames(key)}
          />
        ))}
      </Folder>
    </>
  );
};
