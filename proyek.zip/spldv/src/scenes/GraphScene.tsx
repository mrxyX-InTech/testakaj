import React from 'react';
import {C} from '../theme';
import {SceneShell} from '../components/SceneShell';
import {Reveal} from '../components/Reveal';
import {M} from '../components/M';
import {Graph, GLine, GPoint} from '../components/Graph';

const L1 = C.accent; // garis 1: y = 7 - 2x
const L2 = C.fg; // garis 2: y = 5 - x

// Titik koordinat dihitung dari persamaan (sudah diperiksa: kedua garis lewat (2, 3)).
const line1Pts = [0, 1, 2, 3].map((x) => ({x, y: 7 - 2 * x}));
const line2Pts = [0, 1, 2, 3].map((x) => ({x, y: 5 - x}));
const T1_AT = [31.0, 32.2, 33.4, 34.6];
const T2_AT = [37.2, 38.4, 39.6, 40.8];

const points: GPoint[] = [
  ...line1Pts.map((p, i) => ({...p, at: T1_AT[i], color: L1})),
  ...line2Pts.map((p, i) => ({...p, at: T2_AT[i], color: L2})),
];

const lines: GLine[] = [
  {x1: -0.5, y1: 8, x2: 4, y2: -1, at: 50, dur: 2.5, color: L1},
  {x1: -1, y1: 6, x2: 6, y2: -1, at: 53, dur: 2.5, color: L2},
];

const Header: React.FC<{n: number; title: string; at: number; out?: number}> = ({n, title, at, out}) => (
  <Reveal at={at} out={out} style={{position: 'absolute', left: 0, top: 0}}>
    <div style={{fontSize: 30, letterSpacing: 5, color: C.accent, fontWeight: 700}}>LANGKAH {n}</div>
    <div style={{fontSize: 52, fontWeight: 700, marginTop: 4}}>{title}</div>
  </Reveal>
);

const PtTable: React.FC<{
  eq: string;
  color: string;
  xs: number[];
  ys: number[];
  labelAt: number;
  colsAt: number[];
}> = ({eq, color, xs, ys, labelAt, colsAt}) => {
  const cell: React.CSSProperties = {textAlign: 'center', borderBottom: `2px solid ${C.rule}`, padding: '4px 0'};
  return (
    <div>
      <Reveal at={labelAt}>
        <div style={{display: 'flex', alignItems: 'center', gap: 18, marginBottom: 10}}>
          <div style={{width: 44, height: 8, borderRadius: 4, background: color}} />
          <M s={eq} size={44} />
        </div>
      </Reveal>
      <div style={{display: 'grid', gridTemplateColumns: `80px repeat(${xs.length}, 110px)`, fontSize: 50}}>
        <div style={cell}>
          <M s="x" />
        </div>
        {xs.map((v, i) => (
          <Reveal key={`x${i}`} at={colsAt[i]} style={cell}>
            <M s={String(v)} weight={600} />
          </Reveal>
        ))}
        <div style={cell}>
          <M s="y" />
        </div>
        {ys.map((v, i) => (
          <Reveal key={`y${i}`} at={colsAt[i]} style={cell}>
            <M s={String(v)} weight={600} />
          </Reveal>
        ))}
      </div>
    </div>
  );
};

const LegendRow: React.FC<{n: number; eq: string; color: string; at: number; out: number}> = ({n, eq, color, at, out}) => (
  <Reveal at={at} out={out} style={{display: 'flex', alignItems: 'center', gap: 22, marginBottom: 30}}>
    <div style={{width: 70, height: 10, borderRadius: 5, background: color}} />
    <span style={{fontSize: 40, color: C.muted}}>Garis {n}</span>
    <M s={eq} size={56} />
  </Reveal>
);

export const GraphScene: React.FC = () => {
  return (
    <SceneShell scene="graph" tag="BAGIAN 4" title="Metode Grafik">
      {/* Panel kiri */}
      <div style={{position: 'absolute', left: 120, top: 290, width: 900}}>
        <Header n={1} title="Ubah ke bentuk y = …" at={8} out={26.6} />
        <Header n={2} title="Tentukan titik koordinat" at={27} out={47.6} />
        <Header n={3} title="Gambar kedua garis" at={48} out={56.6} />
        <Header n={4} title="Cari titik potong" at={57.4} />
      </div>

      <div style={{position: 'absolute', left: 120, top: 440, width: 900}}>
        {/* Blok A: bentuk y = ... */}
        <Reveal at={2} out={26.6} dur={0.4}>
          <Reveal at={2.5}>
            <M s="2x + y = 7" size={76} color={C.muted} />
          </Reveal>
          <Reveal at={11.5} style={{marginLeft: 60}}>
            <M s="y = 7 - 2x" size={76} mark={{kind: 'box', at: 13, all: true}} />
          </Reveal>
          <Reveal at={4} style={{marginTop: 34}}>
            <M s="x + y = 5" size={76} color={C.muted} />
          </Reveal>
          <Reveal at={19} style={{marginLeft: 60}}>
            <M s="y = 5 - x" size={76} mark={{kind: 'box', at: 20.5, all: true}} />
          </Reveal>
        </Reveal>

        {/* Blok B: tabel titik */}
        <Reveal at={27} out={47.6} dur={0.4} style={{position: 'absolute', left: 0, top: 0}}>
          <PtTable
            eq="y = 7 - 2x"
            color={L1}
            xs={line1Pts.map((p) => p.x)}
            ys={line1Pts.map((p) => p.y)}
            labelAt={30.5}
            colsAt={T1_AT}
          />
          <div style={{height: 36}} />
          <PtTable
            eq="y = 5 - x"
            color={L2}
            xs={line2Pts.map((p) => p.x)}
            ys={line2Pts.map((p) => p.y)}
            labelAt={36.5}
            colsAt={T2_AT}
          />
        </Reveal>

        {/* Blok C: legenda garis */}
        <div style={{position: 'absolute', left: 0, top: 0}}>
          <LegendRow n={1} eq="y = 7 - 2x" color={L1} at={49} out={56.6} />
          <LegendRow n={2} eq="y = 5 - x" color={L2} at={52.5} out={56.6} />
        </div>

        {/* Blok D: titik potong */}
        <Reveal at={58.6} dur={0.5} style={{position: 'absolute', left: 0, top: 0}}>
          <div style={{fontSize: 44, color: C.muted}}>Kedua garis berpotongan di titik</div>
        </Reveal>
        <Reveal at={60} dur={0.8} style={{position: 'absolute', left: 0, top: 70}}>
          <M s="(2, 3)" size={150} weight={700} />
        </Reveal>
        <Reveal at={63.5} style={{position: 'absolute', left: 0, top: 270}}>
          <M s="x = 2     y = 3" size={80} mark={{kind: 'box', at: 65, all: true}} />
        </Reveal>
      </div>

      {/* Grafik */}
      <div style={{position: 'absolute', left: 1090, top: 270}}>
        <Graph at={1.5} points={points} lines={lines} ringAt={59} label={{x: 2, y: 3, text: '(2, 3)'}} />
      </div>
    </SceneShell>
  );
};
