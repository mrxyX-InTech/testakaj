import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {prog} from '../anim';
import {SceneShell} from '../components/SceneShell';
import {Reveal} from '../components/Reveal';
import {LinRow} from '../components/LinRow';

export const IntroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const line = prog(frame, 0.8, 1.2);
  return (
    <SceneShell scene="intro">
      <AbsoluteFill style={{paddingLeft: 160, justifyContent: 'center'}}>
        <Reveal at={0.5} style={{fontSize: 34, color: C.muted, letterSpacing: 6, fontWeight: 600}}>
          MATEMATIKA SMP · KELAS 9
        </Reveal>
        <Reveal
          at={1.0}
          dur={0.9}
          style={{fontSize: 210, fontWeight: 700, lineHeight: 1.05, marginTop: 16, letterSpacing: -4}}
        >
          SPLDV
        </Reveal>
        <div style={{height: 8, width: 560 * line, background: C.accent, borderRadius: 4, margin: '24px 0 30px'}} />
        <Reveal at={2.4} style={{fontSize: 60, fontWeight: 600}}>
          Sistem Persamaan Linear Dua Variabel
        </Reveal>
        <Reveal at={4.2} style={{fontSize: 44, color: C.muted, marginTop: 22}}>
          Eliminasi · Substitusi · Grafik · Campuran
        </Reveal>
      </AbsoluteFill>
      <Reveal at={7} style={{position: 'absolute', left: 1150, top: 360}}>
        <LinRow a="2x" sign="+" b="y" c="7" size={72} />
        <LinRow a="x" sign="+" b="y" c="5" size={72} />
      </Reveal>
    </SceneShell>
  );
};
