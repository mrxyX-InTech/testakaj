import React from 'react';
import {C} from '../theme';
import {SceneShell} from '../components/SceneShell';
import {Reveal} from '../components/Reveal';
import {M} from '../components/M';

const ITEMS = [
  {name: 'Eliminasi', desc: 'menghilangkan variabel', at: 7.0},
  {name: 'Substitusi', desc: 'memasukkan bentuk variabel ke persamaan lain', at: 11.0},
  {name: 'Grafik', desc: 'mencari titik potong dua garis', at: 15.5},
  {name: 'Campuran', desc: 'menggabungkan eliminasi dan substitusi', at: 19.5},
];

export const SummaryScene: React.FC = () => {
  return (
    <SceneShell scene="summary" tag="BAGIAN 6" title="Kesimpulan">
      <div style={{position: 'absolute', left: 120, top: 300, width: 1680}}>
        {ITEMS.map((it) => (
          <Reveal
            key={it.name}
            at={it.at}
            style={{
              display: 'flex',
              alignItems: 'center',
              height: 124,
              borderBottom: `2px solid ${C.rule}`,
            }}
          >
            <div style={{width: 470, fontSize: 64, fontWeight: 700}}>{it.name}</div>
            <div style={{fontSize: 46, color: C.muted, fontWeight: 400}}>{it.desc}</div>
          </Reveal>
        ))}
      </div>
      <Reveal
        at={24.5}
        style={{
          position: 'absolute',
          left: 120,
          top: 850,
          display: 'flex',
          alignItems: 'baseline',
          gap: 36,
        }}
      >
        <span style={{fontSize: 46, color: C.muted}}>Penyelesaian SPLDV:</span>
        <M s="x = 2     y = 3" size={80} />
      </Reveal>
    </SceneShell>
  );
};
