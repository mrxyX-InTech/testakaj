import React from 'react';
import {C} from '../theme';
import {SceneShell} from '../components/SceneShell';
import {Reveal} from '../components/Reveal';
import {LinRow, LINROW_EM} from '../components/LinRow';
import {Rule} from '../components/Rule';
import {Check} from '../components/Check';
import {StepList} from '../components/StepList';
import {M} from '../components/M';

const SIZE = 88;
const ROW_W = SIZE * LINROW_EM;
const BLOCK: React.CSSProperties = {position: 'absolute', left: 860, top: 300, width: 940};

const VerifyRow: React.FC<{label: string; expr: string; at: number; checkAt: number}> = ({
  label,
  expr,
  at,
  checkAt,
}) => (
  <Reveal at={at} style={{marginTop: 34}}>
    <div style={{fontSize: 36, color: C.muted, marginBottom: 6}}>{label}</div>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <M s={expr} size={56} />
      <Check at={checkAt} size={54} />
    </div>
  </Reveal>
);

export const MixedScene: React.FC = () => {
  const box = (at: number, until: number) => ({kind: 'box' as const, at, all: true, until});
  const strike = (at: number) => ({kind: 'strike' as const, at, all: true});

  return (
    <SceneShell scene="mixed" tag="BAGIAN 5" title="Metode Campuran">
      <Reveal at={0.8} style={{position: 'absolute', left: 120, top: 300}}>
        <StepList
          steps={[
            'Eliminasi untuk mendapatkan nilai x',
            'Substitusi untuk mendapatkan nilai y',
            'Verifikasi pada kedua persamaan',
          ]}
          starts={[13, 42, 52]}
          size={42}
          width={660}
        />
      </Reveal>

      {/* Blok 1: eliminasi (persamaan kedua dikali 2 dulu) */}
      <Reveal at={0.1} out={41.4} dur={0.3} style={BLOCK}>
        <Reveal at={4.5}>
          <LinRow a="3x" sign="+" b="2y" c="12" size={SIZE} bMark={[box(14, 28.5), strike(29)]} />
        </Reveal>
        <div style={{position: 'relative', width: ROW_W, height: SIZE * 1.25}}>
          <Reveal at={8} out={19.8} style={{position: 'absolute', left: 0, top: 0}}>
            <LinRow a="x" sign="+" b="y" c="5" size={SIZE} bMark={box(14, 19.5)} />
          </Reveal>
          <Reveal at={20} style={{position: 'absolute', left: 0, top: 0}}>
            <LinRow lead="-" leadAt={26} a="2x" sign="+" b="2y" c="10" size={SIZE} bMark={strike(29.6)} />
          </Reveal>
          <Reveal at={17} out={21} style={{position: 'absolute', left: ROW_W + 30, top: 0, height: SIZE * 1.25, display: 'flex', alignItems: 'center'}}>
            <M s="* 2" size={64} color={C.accent} />
          </Reveal>
        </div>
        <div style={{margin: '10px 0 14px'}}>
          <Rule at={27} width={ROW_W} />
        </div>
        <Reveal at={33.5} style={{paddingLeft: SIZE * 0.8, height: 90}}>
          <M s="3x - 2x = 12 - 10" size={72} />
        </Reveal>
        <Reveal at={36.5} style={{paddingLeft: SIZE * 0.8, marginTop: 8}}>
          <M s="x = 2" size={104} mark={{kind: 'box', at: 38, all: true}} />
        </Reveal>
      </Reveal>

      {/* Blok 2: substitusi */}
      <Reveal at={41.6} dur={0.5} out={51.4} style={BLOCK}>
        <Reveal at={42.2} style={{marginBottom: 10}}>
          <M s="x = 2" size={72} color={C.muted} />
        </Reveal>
        <Reveal at={43.8}>
          <M s="x + y = 5" size={80} />
        </Reveal>
        <Reveal at={46} style={{marginTop: 12}}>
          <M s="[2] + y = 5" size={80} mark={{kind: 'hl', at: 46.4}} />
        </Reveal>
        <Reveal at={48.5} style={{marginTop: 12}}>
          <M s="y = 3" size={80} mark={{kind: 'box', at: 49.5, all: true}} />
        </Reveal>
      </Reveal>

      {/* Blok 3: verifikasi */}
      <Reveal at={51.8} dur={0.5} style={BLOCK}>
        <Reveal at={52.2}>
          <M s="x = 2     y = 3" size={80} />
        </Reveal>
        <VerifyRow label="Persamaan 1" expr="3(2) + 2(3) = 6 + 6 = 12" at={56.5} checkAt={62} />
        <VerifyRow label="Persamaan 2" expr="2 + 3 = 5" at={63} checkAt={67.5} />
      </Reveal>
    </SceneShell>
  );
};
