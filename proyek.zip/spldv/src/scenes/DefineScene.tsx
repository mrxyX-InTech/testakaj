import React from 'react';
import {C} from '../theme';
import {SceneShell} from '../components/SceneShell';
import {Reveal} from '../components/Reveal';
import {LinRow} from '../components/LinRow';
import {M} from '../components/M';
import {Rich} from '../components/Rich';
import {Check} from '../components/Check';

const Card: React.FC<{children: string}> = ({children}) => (
  <div
    style={{
      border: `2px solid ${C.rule}`,
      borderRadius: 22,
      padding: '28px 44px',
      fontSize: 52,
      fontWeight: 600,
    }}
  >
    <Rich>{children}</Rich>
  </div>
);

const Acronym: React.FC = () => (
  <>
    {['Sistem', 'Persamaan', 'Linear', 'Dua', 'Variabel'].map((w, i) => (
      <span key={w} style={{marginRight: 18}}>
        <span style={{color: C.accent, fontWeight: 700}}>{w[0]}</span>
        {w.slice(1)}
      </span>
    ))}
  </>
);

const Brace: React.FC<{height: number}> = ({height}) => (
  <svg width={44} height={height} viewBox="0 0 44 280" preserveAspectRatio="none">
    <path
      d="M38 4 C16 4 20 20 20 46 L20 96 C20 122 12 138 2 140 C12 142 20 158 20 184 L20 234 C20 260 16 276 38 276"
      fill="none"
      stroke={C.accent}
      strokeWidth={5}
      strokeLinecap="round"
    />
  </svg>
);

// Satu slot di kanan sistem: label dulu, lalu diganti hasil pengecekan.
const SideSlot: React.FC<{
  label: string;
  labelAt: number;
  expr: string;
  exprAt: number;
  checkAt: number;
}> = ({label, labelAt, expr, exprAt, checkAt}) => (
  <div style={{position: 'relative', height: 137.5, width: 560}}>
    <Reveal
      at={labelAt}
      out={exprAt - 0.3}
      style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', fontSize: 38, color: C.muted}}
    >
      {label}
    </Reveal>
    <Reveal
      at={exprAt}
      style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', gap: 22}}
    >
      <M s={expr} size={52} />
      <Check at={checkAt} size={56} />
    </Reveal>
  </div>
);

export const DefineScene: React.FC = () => {
  return (
    <SceneShell scene="define" tag="BAGIAN 1" title="Pengertian SPLDV">
      {/* Fase 1: arti SPLDV */}
      <div style={{position: 'absolute', left: 120, top: 330, width: 1680}}>
        <Reveal at={1.5} out={14} style={{fontSize: 140, fontWeight: 700, letterSpacing: -3, lineHeight: 1}}>
          SPLDV
        </Reveal>
        <Reveal at={3.5} out={14} style={{fontSize: 56, fontWeight: 600, marginTop: 28, color: C.fg}}>
          <span style={{color: C.muted, marginRight: 18}}>=</span>
          <Acronym />
        </Reveal>
        <div style={{display: 'flex', gap: 40, marginTop: 80}}>
          <Reveal at={7.5} out={14}>
            <Card>Dua persamaan linear</Card>
          </Reveal>
          <Reveal at={10.5} out={14}>
            <Card>Dua variabel: x dan y</Card>
          </Reveal>
        </div>
      </div>

      {/* Fase 2: contoh sistem + pengecekan */}
      <div style={{position: 'absolute', left: 330, top: 320, display: 'flex', alignItems: 'center', gap: 28}}>
        <Reveal at={15.6} dur={0.8}>
          <Brace height={275} />
        </Reveal>
        <div>
          <Reveal at={17}>
            <LinRow a="2x" sign="+" b="y" c="7" size={110} />
          </Reveal>
          <Reveal at={20.5}>
            <LinRow a="x" sign="+" b="y" c="5" size={110} />
          </Reveal>
        </div>
      </div>
      <div style={{position: 'absolute', left: 1255, top: 320}}>
        <SideSlot label="persamaan 1" labelAt={17.3} expr="2(2) + 3 = 7" exprAt={37} checkAt={38.2} />
        <SideSlot label="persamaan 2" labelAt={20.8} expr="2 + 3 = 5" exprAt={45.2} checkAt={46.4} />
      </div>

      <Reveal at={26.5} style={{position: 'absolute', left: 330, top: 650, width: 1400, fontSize: 48, color: C.muted, lineHeight: 1.3}}>
        <span style={{color: C.fg, fontWeight: 600}}>Penyelesaian</span> = nilai <Rich>x</Rich> dan <Rich>y</Rich> yang memenuhi kedua persamaan sekaligus
      </Reveal>
      <Reveal at={33.5} style={{position: 'absolute', left: 330, top: 820, display: 'flex', alignItems: 'center', gap: 40}}>
        <M
          s="x = 2     y = 3"
          size={78}
          mark={{kind: 'box', at: 50.5, all: true}}
        />
      </Reveal>
    </SceneShell>
  );
};
