import React from 'react';
import {C} from '../theme';
import {SceneShell} from '../components/SceneShell';
import {Reveal} from '../components/Reveal';
import {LinRow, LINROW_EM} from '../components/LinRow';
import {BoxOverlay} from '../components/Rule';
import {ArrowDown} from '../components/Check';
import {StepList} from '../components/StepList';
import {M} from '../components/M';

const BLOCK: React.CSSProperties = {position: 'absolute', left: 860, top: 300, width: 940};

export const SubstituteScene: React.FC = () => {
  return (
    <SceneShell scene="substitute" tag="BAGIAN 3" title="Metode Substitusi">
      <Reveal at={0.8} style={{position: 'absolute', left: 120, top: 300}}>
        <StepList
          steps={[
            'Ubah salah satu persamaan menjadi x = … atau y = …',
            'Masukkan bentuk itu ke persamaan lainnya',
            'Selesaikan persamaan satu variabel',
            'Tentukan variabel kedua',
          ]}
          starts={[9, 22.5, 32, 45]}
          size={40}
          width={660}
        />
      </Reveal>

      {/* Blok 1: ubah persamaan kedua menjadi y = ... */}
      <Reveal at={0.1} out={21.5} dur={0.3} style={BLOCK}>
        <Reveal at={2.5}>
          <LinRow a="2x" sign="+" b="y" c="7" size={88} />
        </Reveal>
        <Reveal at={4}>
          <div style={{position: 'relative', width: 88 * LINROW_EM}}>
            <LinRow a="x" sign="+" b="y" c="5" size={88} />
            <BoxOverlay at={10} />
          </div>
        </Reveal>
        <div style={{height: 56, paddingLeft: 100, paddingTop: 8}}>
          <ArrowDown at={16} size={44} />
        </div>
        <Reveal at={17}>
          <M s="y = 5 - x" size={88} mark={{kind: 'box', at: 19, all: true}} style={{marginLeft: 70}} />
        </Reveal>
      </Reveal>

      {/* Blok 2: substitusi ke persamaan pertama, selesaikan x */}
      <Reveal at={22} dur={0.5} out={44.2} style={BLOCK}>
        <Reveal at={22.2} style={{marginBottom: 8}}>
          <M s="y = 5 - x" size={60} color={C.muted} />
        </Reveal>
        <Reveal at={23.5}>
          <M s="2x + [y] = 7" size={80} mark={{kind: 'box', at: 24.5, color: C.y}} />
        </Reveal>
        <Reveal at={27} style={{marginTop: 14}}>
          <M s="2x + [(5 - x)] = 7" size={80} mark={{kind: 'hl', at: 28}} />
        </Reveal>
        <Reveal at={35} style={{marginTop: 14}}>
          <M s="x + 5 = 7" size={80} />
        </Reveal>
        <Reveal at={39} style={{marginTop: 14}}>
          <M s="x = 7 - 5" size={80} />
        </Reveal>
        <Reveal at={41.5} style={{marginTop: 14}}>
          <M s="x = 2" size={80} mark={{kind: 'box', at: 43, all: true}} />
        </Reveal>
      </Reveal>

      {/* Blok 3: cari y */}
      <Reveal at={44.8} dur={0.5} style={BLOCK}>
        <Reveal at={45.5} style={{marginBottom: 8}}>
          <M s="x = 2" size={60} color={C.muted} />
        </Reveal>
        <Reveal at={47}>
          <M s="y = 5 - x" size={80} />
        </Reveal>
        <Reveal at={51} style={{marginTop: 14}}>
          <M s="y = 5 - [2]" size={80} mark={{kind: 'hl', at: 51.3}} />
        </Reveal>
        <Reveal at={53.5} style={{marginTop: 14}}>
          <M s="y = 3" size={80} mark={{kind: 'box', at: 54.5, all: true}} />
        </Reveal>
      </Reveal>

      <Reveal at={58} style={{position: 'absolute', left: 860, top: 840}}>
        <M s="x = 2     y = 3" size={84} />
      </Reveal>
    </SceneShell>
  );
};
