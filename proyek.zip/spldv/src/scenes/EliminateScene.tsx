import React from 'react';
import {C} from '../theme';
import {SceneShell} from '../components/SceneShell';
import {Reveal} from '../components/Reveal';
import {LinRow, LINROW_EM} from '../components/LinRow';
import {Rule} from '../components/Rule';
import {StepList} from '../components/StepList';
import {M} from '../components/M';
import {Rich} from '../components/Rich';

const SIZE = 88;
const ROW_W = SIZE * LINROW_EM;

export const EliminateScene: React.FC = () => {
  const strike = (at: number) => ({kind: 'strike' as const, at, all: true});
  const yBox = {kind: 'box' as const, at: 9.5, all: true, until: 26};

  return (
    <SceneShell scene="eliminate" tag="BAGIAN 2" title="Metode Eliminasi">
      <Reveal at={0.8} style={{position: 'absolute', left: 120, top: 300}}>
        <StepList
          steps={[
            'Samakan koefisien salah satu variabel (jika perlu)',
            'Hilangkan variabel dengan penjumlahan atau pengurangan',
            'Tentukan nilai variabel yang tersisa',
            'Substitusikan untuk mencari variabel lainnya',
          ]}
          starts={[8.5, 17.5, 31, 42]}
          size={40}
          width={660}
        />
      </Reveal>

      {/* Blok 1: eliminasi y */}
      <Reveal at={0.1} out={40.6} dur={0.3} style={{position: 'absolute', left: 860, top: 300, width: 940}}>
        <div style={{position: 'relative'}}>
          <Reveal at={2.0}>
            <LinRow a="2x" sign="+" b="y" c="7" size={SIZE} bMark={[yBox, strike(27)]} />
          </Reveal>
          <Reveal at={3.2}>
            <LinRow lead="-" leadAt={19} a="x" sign="+" b="y" c="5" size={SIZE} bMark={[yBox, strike(27.6)]} />
          </Reveal>
          <div style={{margin: '10px 0 14px'}}>
            <Rule at={20} width={ROW_W} />
          </div>
          <Reveal at={33} style={{paddingLeft: SIZE * 0.8, height: 90}}>
            <M s="2x - x = 7 - 5" size={72} />
          </Reveal>
          <Reveal at={37} style={{paddingLeft: SIZE * 0.8, marginTop: 8}}>
            <M s="x = 2" size={104} mark={{kind: 'box', at: 38.5, all: true}} />
          </Reveal>
          <Reveal
            at={10}
            out={17}
            style={{position: 'absolute', left: SIZE * 0.8, top: 268, fontSize: 44, color: C.muted, whiteSpace: 'nowrap'}}
          >
            <Rich>koefisien y sudah sama (1)</Rich>
          </Reveal>
        </div>
      </Reveal>

      {/* Blok 2: substitusi ke persamaan kedua */}
      <Reveal at={41} dur={0.5} style={{position: 'absolute', left: 860, top: 300, width: 940}}>
        <Reveal at={41.8} style={{marginBottom: 10}}>
          <M s="x = 2" size={72} color={C.muted} />
        </Reveal>
        <Reveal at={43}>
          <M s="x + y = 5" size={76} />
        </Reveal>
        <Reveal at={45.5} style={{marginTop: 10}}>
          <M s="[2] + y = 5" size={76} mark={{kind: 'hl', at: 45.9, all: false}} />
        </Reveal>
        <Reveal at={48.5} style={{marginTop: 10}}>
          <M s="y = 5 - 2" size={76} />
        </Reveal>
        <Reveal at={51} style={{marginTop: 10}}>
          <M s="y = 3" size={76} mark={{kind: 'box', at: 52.5, all: true}} />
        </Reveal>
      </Reveal>

      {/* Hasil akhir dan catatan */}
      <Reveal at={55} out={59.5} style={{position: 'absolute', left: 860, top: 840}}>
        <M s="x = 2     y = 3" size={84} />
      </Reveal>
      <Reveal
        at={60.5}
        style={{position: 'absolute', left: 860, top: 840, width: 940, fontSize: 44, color: C.muted, lineHeight: 1.3}}
      >
        Koefisien belum sama? Kalikan dulu persamaannya.
      </Reveal>
    </SceneShell>
  );
};
