# SPLDV - MrXyStudy (Remotion)

Video pembelajaran SPLDV kelas 9 SMP. 1920x1080, 30 FPS, durasi 6 menit 27 detik (11.610 frame).

## Menjalankan

```bash
npm install
npm run dev        # pratinjau di Remotion Studio (komposisi "SPLDV", plus tiap scene di folder "Scenes")
npm run render     # hasil: out/spldv.mp4
```

Saat render pertama, font Inter diunduh dari Google Fonts lewat `@remotion/google-fonts`,
jadi komputer perlu terhubung internet.

## Struktur

| Scene | Durasi | Isi |
|---|---|---|
| intro | 0:16 | Judul |
| define | 0:57 | Pengertian SPLDV, contoh, pengecekan x=2 y=3 |
| eliminate | 1:10 | Eliminasi, langkah demi langkah dengan coretan variabel |
| substitute | 1:06 | Substitusi |
| graph | 1:10 | Grafik dengan bidang koordinat akurat, titik potong (2, 3) |
| mixed | 1:12 | Campuran: 3x + 2y = 12 dan x + y = 5, plus verifikasi |
| summary | 0:36 | Ringkasan empat metode |

Komponen reusable ada di `src/components/`:
`SceneShell` (judul, fade, jalur narasi), `M` (teks matematika, x biru dan y oranye otomatis,
bisa dicoret/dikotaki), `LinRow` (baris persamaan berkolom sejajar), `Graph` (bidang koordinat),
`StepList`, `Reveal`, `Rule`, `Check`, `Watermark`.

Durasi scene diatur di `src/timeline.ts`.

## Narasi

Naskah lengkap ada di `NARASI.md` (sumber: `src/narration.json`). Setiap segmen punya detik mulai
yang sudah disinkronkan dengan animasi.

1. Buat satu file per segmen dan simpan sebagai `public/narasi/<id>.mp3`, misalnya `define-2.mp3`.
   Bisa direkam sendiri atau dibuat otomatis:
   `ELEVENLABS_API_KEY=... ELEVENLABS_VOICE_ID=... npm run narasi`
2. Periksa durasi: `node scripts/check-narration.mjs` (butuh ffprobe). Tiap file harus lebih pendek
   dari jeda ke segmen berikutnya.
3. Ubah `HAS_NARRATION` menjadi `true` di `src/config.ts`.

Kalau suara Anda lebih lambat/cepat dari perkiraan, geser nilai `at` di `src/narration.json` dan
detik animasi yang bersangkutan di file scene.

## Watermark dan musik

- Watermark: `public/logo-white.png` (dari logo yang Anda kirim, dipotong rapi dan dijadikan putih
  transparan, bentuk tidak diubah). Kanan atas, lebar 150 px, opacity 70%, tampil sepanjang video.
- Musik: `public/music/ambient.mp3` (instrumental ambient buatan sendiri, bebas hak cipta),
  volume diatur di `src/config.ts` (`MUSIC_VOLUME`, default 0,10) dengan fade in/out.
